<?php 
     include_once('connect.php');

     if(isset($_POST['atualizar'])){

        $idUser = $_POST['idUser'];
        $aprovado = $_POST['aprovado'];

        $sqlUpdateSolicitacao = "UPDATE aceiteEvento SET aprovado='Sim' WHERE idUser='$idUser'";

        $resultado = $conexao->query($sqlUpdateSolicitacao);

     }
     header('Location: solicitacoes.php')

?>