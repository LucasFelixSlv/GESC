<?php

    session_start();
    include_once('connect.php');

    // Buscar dados do evento

    $sql = "SELECT idUser, nomeUsuario, email, telefone, aprovado FROM `aceiteEvento`;";
    $result = $conexao->query($sql);
    $dadosSolicitacao = $result->fetch_assoc();

?>

<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GESC - Admin</title>
    <script src="script.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    
  </head>

  <body>
    
    
    <header class="bg-black text-white text-center">
        <div class="container">
            <div class="row"> 
                <div class="col-md-12">
                    <h1>Administração</h1>
                </div>
            </div>
        </div>
    </header>


    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="adicionar.php">Adicionar novo Evento</a>
                    </li>
                    <li class="nav-item ps-5">
                        <a class="nav-link" href="escolherEditar.php">Editar Evento</a>
                    </li>
                    <li class="nav-item ps-5">
                        <a class="nav-link" href="avaliacoes.php">Ver Avaliações</a>
                    </li>
                    <li class="nav-item ps-5">
                        <a class="nav-link" href="solicitacoes.php">Aprovar Solicitações</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
  
      <!-- Conteúdo Principal -->
    <form action="salvarSolicitacao.php" method="POST">
      <div class="m-4">
          <table class="table">
              <thead>
                  <tr>
                  <th scope="col">Evento</th>
                  <th scope="col">Solicitações</th>
                  <th scope="col">Nome</th>
                  <th scope="col">Email</th>
                  <th scope="col">Telefone</th>
                  <th scope="col">Aprovar</th>
                  </tr>
              </thead>
              <tbody>
                  <?php

                      $result->data_seek(0);

                      while($dadosSolicitacao = mysqli_fetch_assoc($result)) {
                  ?>

                  <input type="hidden" value="<?= $dadosSolicitacao["idUser"] ?>">
                    <tr>
                      <td><?= $dadosSolicitacao["nome"] ?></td>
                      <td><?= $dadosSolicitacao["somaTotal"] ?></td>
                      <td><?= $dadosSolicitacao["nomeUsuario"] ?></td>
                      <td><?= $dadosSolicitacao["email"] ?></td>
                      <td><?= $dadosSolicitacao["telefone"] ?></td>
                      <td>
                    
                        <div class="form-check form-switch">
                          <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault" value="Sim">
                          <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                        </div>
                    
                    
                    </td>
                    </tr>
                  <?php
                    }
                  ?>
                </tbody>
            </table>

            <div class="container">
            
              <div class="col text-end">
              <button type="submit" name="atualizar" class="btn btn btn-success">Salvar</button>
              </div>
            </div>    
          </div>  
        </form> 
    <link rel="stylesheet" href="style.css"> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>


</html>