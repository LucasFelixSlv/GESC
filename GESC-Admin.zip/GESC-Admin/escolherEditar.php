<?php

    session_start();
    include_once('connect.php');

    // Buscar dados do evento

    $sql = "SELECT idEvento, nome, localEv,  dataEv FROM `eventos`";
    $result = $conexao->query($sql);
    $dadosEvento = $result->fetch_assoc();

?>

<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GESC - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

    
  </head>

  <body>
    
    <header class="bg-black text-white text-center">
        <div class="container">
            <div class="row"> 
                <div class="col-md-12">
                    <h1>Administração</h1>
                </div>
            </div>
        </div>
    </header>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="adicionar.php">Adicionar novo Evento</a>
                    </li>
                    <li class="nav-item ps-5">
                        <a class="nav-link" href="escolherEditar.php">Editar Evento</a>
                    </li>
                    <li class="nav-item ps-5">
                        <a class="nav-link" href="avaliacoes.php">Ver Avaliações</a>
                    </li>
                    <li class="nav-item ps-5">
                        <a class="nav-link" href="solicitacoes.php">Aprovar Solicitações</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
            
            <!-- Conteúdo Principal -->
        <div class="table-responsive m-4">
            <table class="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col" class="w-50">Nome do Evento</th>
                    <th scope="col">Local</th>
                    <th scope="col">Data</th>
                    <th scope="col">...</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                        $result->data_seek(0);
        
                            while($dadosEvento = mysqli_fetch_assoc($result)) {

                        ?>

                                <tr>
                                    <td><?= $dadosEvento['idEvento'] ?> </td>
                                    <td class='text-break'><?= $dadosEvento["nome"] ?></td>
                                    <td><?= $dadosEvento["localEv"] ?></td>
                                    <td><?= $dadosEvento["dataEv"] ?></td>
                                <td>
                               

                                <button type="button" name="idUserUpdate" class="btnTeste" data-bs-toggle="modal" data-bs-target="#modalUpdate<?= $dadosEvento['idEvento'] ?>">
                                    <i class="bi bi-pencil-fill"></i>Ed
                                </button>
                                
                                <button type="button" name="modalDelete" class="btnTeste" data-bs-toggle="modal" data-bs-target="#modalDelete<?= $dadosEvento['idEvento'] ?>">
                                    <i class="bi bi-pencil-fill"></i>Ed
                                </button>
                            </td>
                        </tr>
                        <?php
                            }
                        ?>

                    </tbody>
                    <!--modal edit start-->
                    <div class="modal fade" id="modalDelete<?= $dadosEvento['idEvento'] ?>" tabindex="-1" aria-labelledby="modalUpDelete<?= $dadosEvento['idEvento'] ?>" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Deseja excluir esse evento?</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
   


            <div class='modal-footer'>
                <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Fechar</button>
                <button type='submit' class='btn btn btn-danger'>
                <a href="deleteuser.php?id=<?= $dadosEvento['idEvento']; ?>">
                </button>
            </div>
            
        
        <input type="text"  value="<?= $idExclusao?>">


            </div>
        </div>
        </div>
       
    <link rel="stylesheet" href="style.css"> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>


</html>